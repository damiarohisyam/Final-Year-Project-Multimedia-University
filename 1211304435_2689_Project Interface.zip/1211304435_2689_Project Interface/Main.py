
import pandas as pd
import numpy as np
import tkinter as tk
from tkinter import messagebox
from sklearn.preprocessing import MinMaxScaler
from sklearn.ensemble import RandomForestClassifier
from joblib import load

# Load and prepare the data (replace with your data loading logic)
df_clean_encode = pd.read_csv('FINAL_CLEANED_EPL_DATA_TEST.csv')

# Define features and target
features = df_clean_encode.columns[df_clean_encode.columns != 'Full_Time_Result_LabelEncoded']
target = 'Full_Time_Result_LabelEncoded'

# Identify numerical features to normalize
numerical_features = ['Half_Time_Result_LabelEncoded','Half_Time_Home_Team_Goals', 'Half_Time_Away_Team_Goals', 
                      'Home_Team_Shots_on_Target', 'Away_Team_Shots_on_Target', 
                      'Away_Team_Shots', 'Home_Team_Shots', 'Home_Team_Yellow_Cards', 
                      'Home_Team_Red_Cards', 'Away_Team_Red_Cards']

# Normalize only the numerical features
scaler = MinMaxScaler()
scaler.fit(df_clean_encode[numerical_features])

# Load the trained model
model = load('best_random_forest_model.joblib')

# Function to predict outcome and display details of the most similar past match
def predict_and_evaluate(features):
    try:
        # Predict using the loaded model
        prediction = model.predict([features])[0]
        result_mapping = {0: "Away Win", 1: "Draw", 2: "Home Win"}
        result_text = result_mapping[prediction]

        # Normalize input features (assuming 'features' is a list of numerical values)
        features_array = np.array(features).reshape(1, -1)
        features_scaled = scaler.transform(features_array)

        # Load the new dataset
        df_find_similar = pd.read_csv('TOFINDSIMILAR1.csv')

        # Normalize only the numerical features in the new dataset
        df_find_similar_scaled = df_find_similar.copy()
        df_find_similar_scaled[numerical_features] = scaler.transform(df_find_similar[numerical_features])

        # Calculate distances using numerical features
        distances = np.linalg.norm(df_find_similar_scaled[numerical_features].values - features_scaled, axis=1)
        nearest_index = np.argmin(distances)
        nearest_match = df_find_similar.iloc[nearest_index]

        # Get actual result for the nearest match
        actual_result_label_encoded = nearest_match.get(target, np.nan)
        actual_result = result_mapping.get(actual_result_label_encoded, "Unknown")

        message_text = (
            f"Game Date: {nearest_match.get('Date', 'Unknown')}\n\n"
            f"Home Team: {nearest_match.get('HomeTeam', 'Unknown')}\n\n"
            f"Away Team: {nearest_match.get('AwayTeam', 'Unknown')}\n\n\n"
            f"Half Time Result: {result_mapping.get(nearest_match.get('Half_Time_Result_LabelEncoded'), 'Unknown')}\n\n"
            f"Half Time Home Goals: {int(nearest_match.get('Half_Time_Home_Team_Goals', 0))}\n\n"
            f"Half Time Away Goals: {int(nearest_match.get('Half_Time_Away_Team_Goals', 0))}\n\n"
            f"Home Team Shots on Target: {int(nearest_match.get('Home_Team_Shots_on_Target', 0))}\n\n"
            f"Away Team Shots on Target: {int(nearest_match.get('Away_Team_Shots_on_Target', 0))}\n\n"
            f"Away Team Shots: {int(nearest_match.get('Away_Team_Shots', 0))}\n\n"
            f"Home Team Shots: {int(nearest_match.get('Home_Team_Shots', 0))}\n\n"
            f"Home Team Yellow Cards: {int(nearest_match.get('Home_Team_Yellow_Cards', 0))}\n\n"
            f"Home Team Red Cards: {int(nearest_match.get('Home_Team_Red_Cards', 0))}\n\n"
            f"Away Team Red Cards: {int(nearest_match.get('Away_Team_Red_Cards', 0))}\n\n\n"
            f"Full Time Result (Actual): {actual_result}\n\n"
            f"Full Time Result (Predicted): {result_text}\n\n\n"
            f"Full Time Home Team Goal: {int(nearest_match.get('Full_Time_Home_Team_Goals', 'Unknown'))}\n\n"
            f"Full Time Away Team Goal: {int(nearest_match.get('Full_Time_Away_Team_Goals', 'Unknown'))}\n\n"
        )

        # Display results in message boxes
        messagebox.showinfo("Prediction Result", f"The predicted result is: {result_text}")
        messagebox.showinfo("Similar Past Match", message_text)

    except ValueError as ve:
        messagebox.showerror("Input Error", str(ve))

# Tkinter GUI setup
root = tk.Tk()
root.title("Football Match Prediction System")

# Function to handle radio button selection
def set_result(value):
    result.set(value)

# Initialize variable to store selected result
result = tk.IntVar()

# Labels and radio buttons for Half Time Result
tk.Label(root, text="Half Time Result").grid(row=0, column=0, padx=(20, 10), pady=10)

tk.Radiobutton(root, text="Away Win", variable=result, value=0, command=lambda: set_result(0)).grid(row=0, column=1, padx=10)
tk.Radiobutton(root, text="Draw", variable=result, value=1, command=lambda: set_result(1)).grid(row=0, column=2, padx=10)
tk.Radiobutton(root, text="Home Win", variable=result, value=2, command=lambda: set_result(2)).grid(row=0, column=3, padx=(10, 20))

# Left side labels and entries (mostly numeric)
tk.Label(root, text="Half Time Home Goals").grid(row=1, column=0, padx=(20, 10), pady=10)
Half_Time_Home_Goals = tk.Entry(root, validate='key')
Half_Time_Home_Goals.config(validate='key', validatecommand=(root.register(lambda s: s.isdigit() or s == ""), '%P'))
Half_Time_Home_Goals.grid(row=1, column=1, padx=10)

tk.Label(root, text="Half Time Away Goals").grid(row=2, column=0, padx=(20, 10), pady=10)
Half_Time_Away_Goals = tk.Entry(root, validate='key')
Half_Time_Away_Goals.config(validate='key', validatecommand=(root.register(lambda s: s.isdigit() or s == ""), '%P'))
Half_Time_Away_Goals.grid(row=2, column=1, padx=10)

tk.Label(root, text="Home Team Shots on Target").grid(row=3, column=0, padx=(20, 10), pady=10)
Home_Team_Shots_on_Target = tk.Entry(root, validate='key')
Home_Team_Shots_on_Target.config(validate='key', validatecommand=(root.register(lambda s: s.isdigit() or s == ""), '%P'))
Home_Team_Shots_on_Target.grid(row=3, column=1, padx=10)

tk.Label(root, text="Away Team Shots on Target").grid(row=4, column=0, padx=(20, 10), pady=10)
Away_Team_Shots_on_Target = tk.Entry(root, validate='key')
Away_Team_Shots_on_Target.config(validate='key', validatecommand=(root.register(lambda s: s.isdigit() or s == ""), '%P'))
Away_Team_Shots_on_Target.grid(row=4, column=1, padx=10)

# Right side labels and entries (mostly numeric)
tk.Label(root, text="Away Team Shots").grid(row=1, column=2, padx=(10, 20), pady=10)
Away_Team_Shots = tk.Entry(root, validate='key')
Away_Team_Shots.config(validate='key', validatecommand=(root.register(lambda s: s.isdigit() or s == ""), '%P'))
Away_Team_Shots.grid(row=1, column=3, padx=10)

tk.Label(root, text="Home Team Shots").grid(row=2, column=2, padx=(10, 20), pady=10)
Home_Team_Shots = tk.Entry(root, validate='key')
Home_Team_Shots.config(validate='key', validatecommand=(root.register(lambda s: s.isdigit() or s == ""), '%P'))
Home_Team_Shots.grid(row=2, column=3, padx=10)

# Bottom labels and entries (mixed, but follow numeric entry fields)
tk.Label(root, text="Home Team Yellow Cards").grid(row=3, column=2, padx=(10, 20), pady=10)
Home_Team_Yellow_Cards = tk.Entry(root, validate='key')
Home_Team_Yellow_Cards.config(validate='key', validatecommand=(root.register(lambda s: s.isdigit() or s == ""), '%P'))
Home_Team_Yellow_Cards.grid(row=3, column=3, padx=10)
tk.Label(root, text="Home Team Red Cards").grid(row=4, column=2, padx=(10, 20), pady=10)
Home_Team_Red_Cards = tk.Entry(root, validate='key')
Home_Team_Red_Cards.config(validate='key', validatecommand=(root.register(lambda s: s.isdigit() or s == ""), '%P'))
Home_Team_Red_Cards.grid(row=4, column=3, padx=10)

tk.Label(root, text="Away Team Red Cards").grid(row=5, column=2, padx=(10, 20), pady=10)
Away_Team_Red_Cards = tk.Entry(root, validate='key')
Away_Team_Red_Cards.config(validate='key', validatecommand=(root.register(lambda s: s.isdigit() or s == ""), '%P'))
Away_Team_Red_Cards.grid(row=5, column=3, padx=10)

# Predict button
def on_predict():
    # Check if all required entries are filled
    if (result.get() is None or 
        Half_Time_Home_Goals.get() == '' or 
        Half_Time_Away_Goals.get() == '' or 
        Home_Team_Shots_on_Target.get() == '' or 
        Away_Team_Shots_on_Target.get() == '' or 
        Away_Team_Shots.get() == '' or 
        Home_Team_Shots.get() == '' or 
        Home_Team_Yellow_Cards.get() == '' or 
        Home_Team_Red_Cards.get() == '' or 
        Away_Team_Red_Cards.get() == ''):
        
        messagebox.showwarning("Input Required", "Please insert all match statistics before predicting.")
        return

    # Proceed with prediction if all inputs are filled
    features = [
        result.get(),
        int(Half_Time_Home_Goals.get() or 0),
        int(Half_Time_Away_Goals.get() or 0),
        int(Home_Team_Shots_on_Target.get() or 0),
        int(Away_Team_Shots_on_Target.get() or 0),
        int(Away_Team_Shots.get() or 0),
        int(Home_Team_Shots.get() or 0),
        int(Home_Team_Yellow_Cards.get() or 0),
        int(Home_Team_Red_Cards.get() or 0),
        int(Away_Team_Red_Cards.get() or 0)
    ]
    predict_and_evaluate(features)

predict_button = tk.Button(root, text="Predict Football Match Result", command=on_predict)
predict_button.grid(row=6, columnspan=4, pady=10, padx=(20, 20), sticky='we')

root.mainloop()
